"""Train a simple Fully CNN for Image Segmentation."""

import numpy as np
from PIL import Image
import tensorflow as tf
import numpy as np
import os


MODEL_DIR = "models"


def create_model(input_shape=(500, 500, 3)):
    """CNN to classify each pixel in an image as roof or non-roof."""
    img_input = tf.keras.layers.Input(shape=input_shape)
    # Encoder
    conv1 = tf.keras.layers.Conv2D(16, (3, 3), activation='relu')(img_input)
    conv1 = tf.keras.layers.Conv2D(16, (5, 5), activation='relu')(conv1)
    pool1 = tf.keras.layers.MaxPool2D((2, 2))(conv1)
    conv2 = tf.keras.layers.Conv2D(32, (3, 3), activation='relu')(pool1)
    conv2 = tf.keras.layers.Conv2DTranspose(32, (2, 2))(conv2)
    conv3 = tf.keras.layers.Conv2D(16, (3, 3))(conv2)

    # Decoder
    conv4 = tf.keras.layers.Conv2DTranspose(16, (3, 3))(conv3)
    conv5 = tf.keras.layers.Conv2D(32, (2, 2))(conv4)
    conv5 = tf.keras.layers.Conv2DTranspose(
        32, (3, 3), activation='relu')(conv5)
    up1 = tf.keras.layers.concatenate([
        tf.keras.layers.UpSampling2D((2, 2))(conv5),
        conv1
    ], axis=-1)  # Up sampling with a skip connection
    conv6 = tf.keras.layers.Conv2DTranspose(16, (5, 5), activation='relu')(up1)
    conv6 = tf.keras.layers.Conv2DTranspose(
        16, (3, 3), activation='relu')(conv6)

    # output
    out = tf.keras.layers.Conv2D(1, (1, 1), activation='sigmoid')(conv6)

    return tf.keras.Model(img_input, out)


def partition_image(arr, w, h):
    """Partition a 2D array into tiles of width w and height h."""
    return [arr[np.newaxis, x:x + w, y:y + h] for x in range(0, arr.shape[0], w) for y in range(0, arr.shape[1], h)]


def load_data(tile_width=500, tile_height=500, input_img="image.tif", labels_img="labels.tif"):
    """Read the TIF data into a tf.data loader."""
    # input_img is a 3-channel image of data in [0, 255]
    input_image = np.array(Image.open(input_img), dtype=np.float32)[:, :, :3]
    # label_img is a 1-channel image (mask) of data in {0, 255}
    label_image = np.array(Image.open(labels_img), dtype=np.uint8)

    # Normalize inputs to be floats in [0, 1] and labels to be ints in {0, 1}
    input_image /= 255
    label_image //= 255

    input_tiles = partition_image(input_image, tile_width, tile_height)
    label_tiles = partition_image(label_image, tile_width, tile_height)

    return tf.data.Dataset.from_tensor_slices((input_tiles, label_tiles))


if __name__ == "__main__":
    if not os.path.isdir(MODEL_DIR):
        os.mkdir(MODEL_DIR)

    model_fn = os.path.join(MODEL_DIR, "model.h5")

    model = create_model()
    train_data = load_data()

    model.compile(optimizer="adam", loss="categorical_crossentropy")
    model.fit(train_data, epochs=100)

    model.save(model_fn)

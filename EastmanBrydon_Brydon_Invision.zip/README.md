# Image Segmentation for Roof Recognition

## To Run:
  - `train.py` trains the network on data from `image.tif` and `labels.tif` and saves the CNN into a `model.h5` file in the `models` directory (if models doesn't exist, it is created)
  - `prediction.py` loads the pre-trained network and creates a file `output.jpg` based on the CNNs prediction of the `image.tif` data. The output image is saved in the `plots` directory (which is created if it doesn't already exist)
  - Any questions, please don't hesitate to contact me: `brydon.eastman@gmail.com`

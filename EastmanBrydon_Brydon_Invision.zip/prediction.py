"""Run prediction on a fully CNN network and save the output."""

import numpy as np
from PIL import Image
import tensorflow as tf
import numpy as np
import os
from train import load_data


MODEL_DIR = "models"
PLOTS_DIR = "plots"


def stitch(arr):
    """Stitch tiles back into one cohesive image."""
    n = int(np.sqrt(len(arr)))
    w, h = arr[0].shape[:2]
    out_shape = list(arr[0].shape)
    out_shape[:2] = n * w, n * h

    out_arr = np.zeros(out_shape)
    for i, tile in enumerate(arr):
        x = i // n
        y = i % n
        out_arr[x * w:(x + 1) * w, y * h:(y + 1) * h] = tile

    return out_arr


if __name__ == "__main__":
    if not os.path.isdir(PLOTS_DIR):
        os.mkdir(PLOTS_DIR)

    plot_fn = os.path.join(PLOTS_DIR, "output.jpg")

    model_fn = os.path.join(MODEL_DIR, "model.h5")
    model = tf.keras.models.load_model(model_fn)

    data = load_data()

    raw_prediction = model.predict(data)
    prediction = stitch(raw_prediction)[:, :, 0]
    im = Image.fromarray(np.uint8(prediction * 255))
    im.save(plot_fn)
